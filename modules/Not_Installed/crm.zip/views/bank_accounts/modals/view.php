<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div class="modal fade" id="viewBankAccountModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <div class="modal-header bg-light-primary">
        <h5 class="modal-title">
          <i class="ti ti-eye me-2"></i> Bank Account Details
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div id="bankAccountViewContent" class="small">
          <div class="text-muted">Select an account to view details.</div>
        </div>

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
