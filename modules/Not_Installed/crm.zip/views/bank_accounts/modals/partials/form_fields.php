<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php $mode = $mode ?? 'add'; ?>

<div class="row">

  <div class="col-md-4 mb-3">
    <label class="form-label">Account Name <span class="text-danger">*</span></label>
    <input type="text" class="form-control" name="account_name" required>
  </div>

  <div class="col-md-4 mb-3">
    <label class="form-label">Bank Name <span class="text-danger">*</span></label>
    <input type="text" class="form-control" name="bank_name" required>
  </div>

  <div class="col-md-4 mb-3">
    <label class="form-label">Account Number <span class="text-danger">*</span></label>
    <input type="text" class="form-control" name="account_number" required>
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Account Type</label>
    <select class="form-select" name="account_type">
      <?php foreach (['checking','savings','current','business','credit_card','digital_wallet','other'] as $t): ?>
        <option value="<?= $t ?>"><?= ucwords(str_replace('_',' ',$t)) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Bank Code</label>
    <input type="text" class="form-control" name="bank_code" placeholder="SWIFT, Routing, IFSC...">
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Bank Code Type</label>
    <select class="form-select" name="bank_code_type">
      <option value="">—</option>
      <?php foreach (['swift','routing','ifsc','sort_code','bsb','iban','other'] as $ct): ?>
        <option value="<?= $ct ?>"><?= strtoupper($ct) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Country</label>
    <input type="text" class="form-control" name="country" value="United States">
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Currency</label>
    <select class="form-select" name="currency">
      <?php foreach (finance_currency_dropdown() as $code => $label): ?>
        <option value="<?= html_escape($code) ?>"><?= html_escape($label) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Account Holder <span class="text-danger">*</span></label>
    <input type="text" class="form-control" name="account_holder" required>
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Holder Type</label>
    <select class="form-select" name="holder_type">
      <option value="individual">Individual</option>
      <option value="company">Company</option>
      <option value="joint">Joint</option>
    </select>
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Opening Balance</label>
    <input type="number" step="0.01" class="form-control" name="opening_balance" value="0.00">
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Current Balance</label>
    <input type="number" step="0.01" class="form-control" name="current_balance" value="0.00">
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Branch</label>
    <input type="text" class="form-control" name="branch">
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Contact Phone</label>
    <input type="text" class="form-control" name="contact_phone">
  </div>

  <div class="col-md-3 mb-3">
    <label class="form-label">Status</label>
    <select class="form-select" name="status">
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
      <option value="closed">Closed</option>
    </select>
  </div>

  <div class="col-md-3 mb-3">
    <div class="form-check form-switch mt-4">
      <input class="form-check-input" type="checkbox" name="is_primary" value="1">
      <label class="form-check-label">Primary Account</label>
    </div>
  </div>

  <div class="col-md-3 mb-3">
    <div class="form-check form-switch mt-4">
      <input class="form-check-input" type="checkbox" name="is_default" value="1">
      <label class="form-check-label">Default Account</label>
    </div>
  </div>

</div>
