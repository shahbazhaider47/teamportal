<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div class="modal fade" id="addBankAccountModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <form method="post" action="<?= site_url('finance/bank_account_add'); ?>" class="app-form">

        <div class="modal-header bg-light-primary">
          <h5 class="modal-title">
            <i class="ti ti-building-bank me-2"></i> Add Bank Account
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
          <?php $this->load->view('finance/bank_accounts/modals/partials/form_fields', ['mode' => 'add']); ?>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">
            <i class="ti ti-device-floppy me-1"></i> Save
          </button>
        </div>

      </form>
    </div>
  </div>
</div>
