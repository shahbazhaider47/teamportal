<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div class="modal fade" id="bankAccountModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">

      <form method="post" action="<?= site_url('finance/bank_account_add'); ?>" id="bankAccountForm">

        <div class="modal-header bg-light-primary">
          <h5 class="modal-title">Bank Account</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body app-form">

          <input type="hidden" name="id" id="bank_account_id">

          <div class="row">

            <!-- Core -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Account Name *</label>
              <input type="text" name="account_name" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Bank Name *</label>
              <input type="text" name="bank_name" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Account Number *</label>
              <input type="text" name="account_number" class="form-control" required>
            </div>

            <div class="col-md-3 mb-3">
              <label class="form-label">Account Type</label>
              <select name="account_type" class="form-select">
                <?php
                $types = [
                  'checking','savings','current','business',
                  'credit_card','digital_wallet','other'
                ];
                foreach ($types as $t):
                ?>
                  <option value="<?= $t; ?>"><?= ucwords(str_replace('_',' ',$t)); ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="col-md-3 mb-3">
              <label class="form-label">Currency</label>
              <select name="currency" class="form-select">
                <?php foreach (finance_currency_dropdown() as $c => $label): ?>
                  <option value="<?= $c; ?>"><?= html_escape($label); ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="col-md-3 mb-3">
              <label class="form-label">Opening Balance</label>
              <input type="number" step="0.01" name="opening_balance" class="form-control">
            </div>

            <div class="col-md-3 mb-3">
              <label class="form-label">Current Balance</label>
              <input type="number" step="0.01" name="current_balance" class="form-control">
            </div>

            <!-- Holder -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Account Holder *</label>
              <input type="text" name="account_holder" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Holder Type</label>
              <select name="holder_type" class="form-select">
                <option value="individual">Individual</option>
                <option value="company">Company</option>
                <option value="joint">Joint</option>
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Contact Phone</label>
              <input type="text" name="contact_phone" class="form-control">
            </div>

            <!-- Bank Codes -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Bank Code</label>
              <input type="text" name="bank_code" class="form-control">
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Bank Code Type</label>
              <select name="bank_code_type" class="form-select">
                <option value="">—</option>
                <?php
                $codes = ['swift','routing','ifsc','sort_code','bsb','iban','other'];
                foreach ($codes as $c):
                ?>
                  <option value="<?= $c; ?>"><?= strtoupper($c); ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Branch</label>
              <input type="text" name="branch" class="form-control">
            </div>

            <!-- Flags -->
            <div class="col-md-3 mb-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="closed">Closed</option>
              </select>
            </div>

            <div class="col-md-3 mb-3 form-check form-switch mt-4">
              <input class="form-check-input" type="checkbox" name="is_primary" value="1">
              <label class="form-check-label">Primary Account</label>
            </div>

            <div class="col-md-3 mb-3 form-check form-switch mt-4">
              <input class="form-check-input" type="checkbox" name="is_default" value="1">
              <label class="form-check-label">Default Account</label>
            </div>

          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="bankAccountSubmit">
            Save
          </button>
        </div>

      </form>

    </div>
  </div>
</div>
