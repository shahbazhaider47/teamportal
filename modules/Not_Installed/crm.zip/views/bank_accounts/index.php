<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div class="container-fluid">

  <div class="d-flex align-items-center justify-content-between mb-3">
    <h5 class="mb-0">Bank Accounts</h5>

    <button type="button"
            class="btn btn-primary btn-sm"
            data-bs-toggle="modal"
            data-bs-target="#addBankAccountModal">
      <i class="ti ti-plus"></i> Add Bank Account
    </button>
  </div>

  <div class="card">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 small">
        <thead class="bg-light">
          <tr>
            <th>#</th>
            <th>Account</th>
            <th>Bank</th>
            <th>Type</th>
            <th>Currency</th>
            <th>Balance</th>
            <th>Status</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!empty($accounts)): ?>
          <?php foreach ($accounts as $i => $acc): ?>
            <tr>
              <td><?= $i + 1; ?></td>
              <td>
                <?= html_escape($acc['account_name']); ?>
                <?php if (!empty($acc['is_primary'])): ?>
                  <span class="badge bg-warning ms-1">Primary</span>
                <?php endif; ?>
                <?php if (!empty($acc['is_default'])): ?>
                  <span class="badge bg-info ms-1">Default</span>
                <?php endif; ?>
              </td>
              <td><?= html_escape($acc['bank_name']); ?></td>
              <td><?= ucwords(str_replace('_',' ',$acc['account_type'])); ?></td>
              <td><?= html_escape($acc['currency']); ?></td>
              <td><?= invc_format((float)$acc['current_balance'], $acc['currency']); ?></td>
              <td>
                <span class="badge bg-<?= $acc['status'] === 'active' ? 'success' : 'secondary'; ?>">
                  <?= ucfirst($acc['status']); ?>
                </span>
              </td>
              <td class="text-end">

                <!-- VIEW -->
                <button type="button"
                        class="btn btn-light btn-sm js-bank-view"
                        data-bs-toggle="modal"
                        data-bs-target="#viewBankAccountModal"
                        data-id="<?= (int)$acc['id']; ?>">
                  View
                </button>

                <!-- EDIT -->
                <button type="button"
                        class="btn btn-light btn-sm js-bank-edit"
                        data-bs-toggle="modal"
                        data-bs-target="#editBankAccountModal"
                        data-id="<?= (int)$acc['id']; ?>">
                  Edit
                </button>

                <!-- DELETE -->
                <a href="<?= site_url('finance/bank_account_delete/'.$acc['id']); ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Delete this bank account?');">
                  Delete
                </a>

              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="8" class="text-center text-muted">
              No bank accounts found.
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<?php $CI = &get_instance(); 
$CI->load->view('finance/bank_accounts/modals/add');
$CI->load->view('finance/bank_accounts/modals/edit');
$CI->load->view('finance/bank_accounts/modals/view');
?>
