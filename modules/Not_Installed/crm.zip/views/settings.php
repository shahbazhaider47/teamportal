<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$CI =& get_instance();
$CI->load->helper('crm/crm');
?>

<style>
.crm-group {
    min-width: 200px;
    max-width: 200px;
    font-size: 12px !important
}
</style>

<div class="mb-4">
    <h5 class="card-title">CRM Settings</h5>
    <p class="text-muted">Configure CRM defaults including lead workflow, pipeline rules, follow-ups, notifications, data validation, and automation policies.</p>
</div>

<div class="row app-form">

    <!-- LEFT COLUMN -->
    <div class="col-md-6">
        <div class="card card-body border-bottom pb-3 mb-4">
            <div class="card-header bg-light-primary py-2 mb-2">
                <h6 class="mb-0 text-muted"><i class="ti ti-target-arrow me-2"></i>Lead Management</h6>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Lead # Prefix</span>
                    <input type="text"
                           class="form-control"
                           name="settings[crm_lead_prefix]"
                           value="<?= e($existing_data['crm_lead_prefix'] ?? 'LD-'); ?>">
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Next Lead Number</span>
                    <input type="number"
                           class="form-control"
                           name="settings[crm_lead_start_num]"
                           min="1"
                           value="<?= e($existing_data['crm_lead_start_num'] ?? 1000); ?>">
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Default Lead Status</span>
                    <select class="form-select" name="settings[crm_default_lead_status]">
                        <?php $v = $existing_data['crm_default_lead_status'] ?? 'new'; ?>
                        <option value="new" <?= $v === 'new' ? 'selected' : '' ?>>New</option>
                        <option value="contacted" <?= $v === 'contacted' ? 'selected' : '' ?>>Contacted</option>
                        <option value="qualified" <?= $v === 'qualified' ? 'selected' : '' ?>>Qualified</option>
                        <option value="proposal" <?= $v === 'proposal' ? 'selected' : '' ?>>Proposal Sent</option>
                        <option value="won" <?= $v === 'won' ? 'selected' : '' ?>>Won</option>
                        <option value="lost" <?= $v === 'lost' ? 'selected' : '' ?>>Lost</option>
                        <option value="nurture" <?= $v === 'nurture' ? 'selected' : '' ?>>Nurture</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Default Lead Quality</span>
                    <select class="form-select" name="settings[crm_default_lead_quality]">
                        <?php $q = $existing_data['crm_default_lead_quality'] ?? 'warm'; ?>
                        <option value="hot" <?= $q === 'hot' ? 'selected' : '' ?>>Hot</option>
                        <option value="warm" <?= $q === 'warm' ? 'selected' : '' ?>>Warm</option>
                        <option value="cold" <?= $q === 'cold' ? 'selected' : '' ?>>Cold</option>
                        <option value="unknown" <?= $q === 'unknown' ? 'selected' : '' ?>>Unknown</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Default Lead Score</span>
                    <input type="number"
                           class="form-control"
                           name="settings[crm_default_lead_score]"
                           min="0"
                           max="100"
                           value="<?= e($existing_data['crm_default_lead_score'] ?? 0); ?>">
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Default Follow-up (Days)</span>
                    <input type="number"
                           class="form-control"
                           name="settings[crm_default_followup_days]"
                           min="0"
                           value="<?= e($existing_data['crm_default_followup_days'] ?? 3); ?>">
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Stale Lead Days</span>
                    <input type="number"
                           class="form-control"
                           name="settings[crm_stale_lead_days]"
                           min="0"
                           value="<?= e($existing_data['crm_stale_lead_days'] ?? 14); ?>">
                </div>
            </div>

            <div class="card card-body mb-3">
                <label class="form-label fw-bold mb-0 text-primary">Lead Automation</label>
                <hr class="mt-1">

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_auto_assign_new_leads]"
                           value="1"
                           <?= !empty($existing_data['crm_auto_assign_new_leads']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Auto-assign New Leads</label>
                    <small class="text-muted d-block">Assign new leads automatically using the default routing policy.</small>
                </div>

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_auto_create_followup_task]"
                           value="1"
                           <?= !empty($existing_data['crm_auto_create_followup_task']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Auto-create Follow-up Task</label>
                    <small class="text-muted d-block">Create a task automatically after creating a new lead.</small>
                </div>

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_auto_mark_stale]"
                           value="1"
                           <?= !empty($existing_data['crm_auto_mark_stale']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Auto-mark Stale Leads</label>
                    <small class="text-muted d-block">Mark leads as stale if not updated within the configured window.</small>
                </div>

                <div class="form-check form-switch mb-0">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_auto_close_lost]"
                           value="1"
                           <?= !empty($existing_data['crm_auto_close_lost']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Auto-close as Lost</label>
                    <small class="text-muted d-block">Auto-close leads as Lost after prolonged inactivity (use stale days as baseline).</small>
                </div>

            </div>

        </div>
    </div>

    <!-- RIGHT COLUMN -->
    <div class="col-md-6">
        <div class="card card-body border-bottom pb-3 mb-4">
            <div class="card-header bg-light-primary py-2 mb-2">
                <h6 class="mb-0 text-muted"><i class="ti ti-git-merge me-2"></i>Pipeline & Deals</h6>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Default Pipeline</span>
                    <select class="form-select" name="settings[crm_default_pipeline]">
                        <?php $p = $existing_data['crm_default_pipeline'] ?? 'standard'; ?>
                        <option value="standard" <?= $p === 'standard' ? 'selected' : '' ?>>Standard</option>
                        <option value="rcm" <?= $p === 'rcm' ? 'selected' : '' ?>>RCM Sales</option>
                        <option value="enterprise" <?= $p === 'enterprise' ? 'selected' : '' ?>>Enterprise</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Default Deal Currency</span>
                    <?php $cur = $existing_data['crm_deal_currency'] ?? 'USD'; ?>
                    <select class="form-select" name="settings[crm_deal_currency]" id="crmDealCurrency">
                        <?php
                        $currencies = function_exists('finance_currency_dropdown')
                            ? finance_currency_dropdown($cur)
                            : [$cur => $cur];

                        foreach ($currencies as $code => $label):
                        ?>
                            <option value="<?= html_escape($code) ?>" <?= $cur === $code ? 'selected' : '' ?>>
                                <?= html_escape($label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">
                        Deal Amount Preview
                        <span class="ms-1 text-muted">
                            <small class="text-primary fw-bold" id="crmDealCurrencyPreview">(<?= html_escape($cur) ?> 1,234.56)</small>
                        </span>
                    </span>
                    <input type="text" class="form-control" value="1,234.56" disabled>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Require Amount for Deal</span>
                    <?php $ra = (string)($existing_data['crm_require_deal_amount'] ?? '0'); ?>
                    <select class="form-select" name="settings[crm_require_deal_amount]">
                        <option value="0" <?= $ra === '0' ? 'selected' : '' ?>>No</option>
                        <option value="1" <?= $ra === '1' ? 'selected' : '' ?>>Yes</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Auto Move Stage</span>
                    <?php $ams = (string)($existing_data['crm_auto_move_stage'] ?? '1'); ?>
                    <select class="form-select" name="settings[crm_auto_move_stage]">
                        <option value="1" <?= $ams === '1' ? 'selected' : '' ?>>Enabled</option>
                        <option value="0" <?= $ams === '0' ? 'selected' : '' ?>>Disabled</option>
                    </select>
                </div>
            </div>

            <div class="card card-body mb-3">
                <label class="form-label fw-bold mb-0 text-primary">Forecast & Probability</label>
                <hr class="mt-1">

                <div class="mb-2">
                    <div class="input-group">
                        <span class="input-group-text crm-group">Default Probability (%)</span>
                        <input type="number"
                               class="form-control"
                               name="settings[crm_default_probability]"
                               min="0" max="100"
                               value="<?= e($existing_data['crm_default_probability'] ?? 25); ?>">
                    </div>
                </div>

                <div class="mb-0">
                    <div class="input-group">
                        <span class="input-group-text crm-group">Forecast Horizon (Days)</span>
                        <input type="number"
                               class="form-control"
                               name="settings[crm_forecast_horizon_days]"
                               min="1"
                               value="<?= e($existing_data['crm_forecast_horizon_days'] ?? 30); ?>">
                    </div>
                </div>

            </div>

        </div>
    </div>

    <div class="col-md-6">
        <div class="card card-body border-bottom pb-3 mb-4">
            <div class="card-header bg-light-primary py-2 mb-2">
                <h6 class="mb-0 text-muted"><i class="ti ti-bell me-2"></i>Notifications & Reminders</h6>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Reminder Frequency (Days)</span>
                    <input type="number"
                           class="form-control"
                           name="settings[crm_reminder_frequency]"
                           min="1"
                           value="<?= e($existing_data['crm_reminder_frequency'] ?? 3); ?>">
                </div>
            </div>

            <div class="card card-body mb-3">
                <label class="form-label fw-bold mb-0 text-primary">Notification Rules</label>
                <hr class="mt-1">

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_notify_on_assign]"
                           value="1"
                           <?= !empty($existing_data['crm_notify_on_assign']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Notify on Assignment</label>
                    <small class="text-muted d-block">Notify assignee when a lead/deal is assigned.</small>
                </div>

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_notify_on_status_change]"
                           value="1"
                           <?= !empty($existing_data['crm_notify_on_status_change']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Notify on Status Change</label>
                    <small class="text-muted d-block">Notify stakeholders when lead status changes.</small>
                </div>

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_notify_on_new_note]"
                           value="1"
                           <?= !empty($existing_data['crm_notify_on_new_note']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Notify on Notes</label>
                    <small class="text-muted d-block">Notify assigned user when notes are added on a lead/deal.</small>
                </div>

                <div class="form-check form-switch mb-0">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_notify_overdue_followups]"
                           value="1"
                           <?= !empty($existing_data['crm_notify_overdue_followups']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Notify Overdue Follow-ups</label>
                    <small class="text-muted d-block">Send alerts when follow-up tasks become overdue.</small>
                </div>

            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card card-body border-bottom pb-3 mb-4">
            <div class="card-header bg-light-primary py-2 mb-2">
                <h6 class="mb-0 text-muted"><i class="ti ti-shield-check me-2"></i>Data Quality & Compliance</h6>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Require Email</span>
                    <?php $re = (string)($existing_data['crm_require_email'] ?? '1'); ?>
                    <select class="form-select" name="settings[crm_require_email]">
                        <option value="1" <?= $re === '1' ? 'selected' : '' ?>>Yes</option>
                        <option value="0" <?= $re === '0' ? 'selected' : '' ?>>No</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Require Phone</span>
                    <?php $rp = (string)($existing_data['crm_require_phone'] ?? '0'); ?>
                    <select class="form-select" name="settings[crm_require_phone]">
                        <option value="1" <?= $rp === '1' ? 'selected' : '' ?>>Yes</option>
                        <option value="0" <?= $rp === '0' ? 'selected' : '' ?>>No</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Auto Validate Emails</span>
                    <?php $ave = (string)($existing_data['crm_auto_validate_email'] ?? '0'); ?>
                    <select class="form-select" name="settings[crm_auto_validate_email]">
                        <option value="1" <?= $ave === '1' ? 'selected' : '' ?>>Enabled</option>
                        <option value="0" <?= $ave === '0' ? 'selected' : '' ?>>Disabled</option>
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <div class="input-group">
                    <span class="input-group-text crm-group">Prevent Duplicates</span>
                    <?php $pd = (string)($existing_data['crm_prevent_duplicates'] ?? '1'); ?>
                    <select class="form-select" name="settings[crm_prevent_duplicates]">
                        <option value="1" <?= $pd === '1' ? 'selected' : '' ?>>Enabled</option>
                        <option value="0" <?= $pd === '0' ? 'selected' : '' ?>>Disabled</option>
                    </select>
                </div>
            </div>

            <div class="card card-body mb-0">
                <label class="form-label fw-bold mb-0 text-primary">Verification</label>
                <hr class="mt-1">

                <div class="form-check form-switch mb-3">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_require_verification_for_won]"
                           value="1"
                           <?= !empty($existing_data['crm_require_verification_for_won']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Require Verification Before Marking Won</label>
                    <small class="text-muted d-block">Force data verification before closing a deal as Won.</small>
                </div>

                <div class="form-check form-switch mb-0">
                    <input class="form-check-input"
                           type="checkbox"
                           role="switch"
                           name="settings[crm_track_data_changes]"
                           value="1"
                           <?= !empty($existing_data['crm_track_data_changes']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Track Data Changes</label>
                    <small class="text-muted d-block">Keep audit logs for changes to critical CRM fields.</small>
                </div>

            </div>

        </div>
    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    // Minimal currency preview without depending on finance JS
    const selectEl  = document.getElementById('crmDealCurrency');
    const previewEl = document.getElementById('crmDealCurrencyPreview');

    if (selectEl && previewEl) {
        selectEl.addEventListener('change', function () {
            const c = this.value || 'USD';
            previewEl.textContent = '(' + c + ' 1,234.56)';
        });
    }

});
</script>