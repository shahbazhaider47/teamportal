<?php
// Build the full sidebar menu array using the same filter pipeline
$menus = [];
if (function_exists('hooks')) {
    $menus = hooks()->apply_filters('app_sidebar_menu', $menus);
}

// Find CRM parent menu
$crmMenu = function_exists('get_menu_by_slug') ? get_menu_by_slug($menus, 'crm_admin') : null;

// If CRM menu not available (no permission or not registered), skip rendering
if (!empty($crmMenu) && !empty($crmMenu['children']) && is_array($crmMenu['children'])):
?>
<div class="dropdown">
    <button class="btn btn-header btn-primary dropdown-toggle" type="button"
            data-bs-toggle="dropdown" aria-expanded="false">
        <i class="<?= html_escape($crmMenu['icon'] ?? 'ti ti-address-book') ?>"></i>
        CRM Menu
    </button>

    <ul class="dropdown-menu p-2">
        <?php
        // Sort children by position (safe)
        $children = $crmMenu['children'];
        usort($children, function ($a, $b) {
            return (int)($a['position'] ?? 0) <=> (int)($b['position'] ?? 0);
        });

        $first = true;
        foreach ($children as $child):
            $name = $child['name'] ?? '';
            $href = $child['href'] ?? '#';
            $icon = $child['icon'] ?? null; // optional if you add icon later
            if ($name === '') continue;

            // Add divider after first item if you want (optional)
            if (!$first): ?>
                <div class="app-divider-v dashed"></div>
            <?php endif; $first = false; ?>

            <li class="small">
                <a class="dropdown-item small" href="<?= html_escape($href) ?>">
                    <?php if ($icon): ?>
                        <i class="<?= html_escape($icon) ?> me-2 text-primary"></i>
                    <?php else: ?>
                        <i class="ti ti-chevron-right me-2 text-primary"></i>
                    <?php endif; ?>
                    <?= html_escape($name) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>