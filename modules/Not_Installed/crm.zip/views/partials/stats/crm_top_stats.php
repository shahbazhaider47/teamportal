        <div class="col-md-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted small">Total Invoices</div>
                    <div class="h5 mb-0">
                        <?= (int) ($stats['total_invoices'] ?? 0); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted small">Total Payments</div>
                    <div class="h5 mb-0">
                        <?= (int) ($stats['total_payments'] ?? 0); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted small">Total Expenses</div>
                    <div class="h5 mb-0">
                        <?= (int) ($stats['total_expenses'] ?? 0); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted small">Net Balance USD</div>
                    <div class="h5 mb-0">
                        <?= html_escape($currency ?? 'USD'); ?>
                        <?= number_format((float) ($stats['balance'] ?? 0), 2); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted small">Net Balance PKR</div>
                    <div class="h5 mb-0">
                        PKR
                        <?= number_format((float) ($stats['balance'] ?? 0), 2); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-muted small">Other</div>
                    <div class="h5 mb-0">
                        <?= number_format((float) ($stats['balance'] ?? 0), 2); ?>
                    </div>
                </div>
            </div>
        </div>        