<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<?php
$leadId   = (int)($lead['id'] ?? 0);
$isDel    = ((int)($lead['is_deleted'] ?? 0) === 1);

// permissions passed from controller? not in view(), so we safely re-check
$canEdit   = staff_can('lead_edit', 'crm') || staff_can('client_edit', 'crm');
$canDelete = staff_can('lead_delete', 'crm') || staff_can('client_delete', 'crm');
$canView   = staff_can('lead_view', 'crm') || staff_can('client_view', 'crm') || staff_can('view', 'crm');
?>

<div class="container-fluid">
    <div class="d-flex align-items-center justify-content-between bg-light-secondary page-header gap-3 px-3 py-1 mb-3 rounded-3 shadow-sm">
      <div class="d-flex align-items-center gap-3 flex-wrap">
        <h1 class="h6 header-title">
            Lead #<?= $leadId; ?>: <span class="small text-muted"><?= html_escape($lead['practice_name'] ?? '—'); ?></span>
        </h1>
        
        <span class="badge bg-light-primary capital"><?= html_escape($lead['lead_status'] ?? '—'); ?></span>
      
      </div>
    
      <div class="d-flex align-items-center gap-2 flex-wrap">

      <a href="<?= site_url('crm/leads'); ?>" class="btn btn-light-primary btn-header">
        <i class="ti ti-arrow-left"></i> Back to Leads
      </a>
      
      </div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="card border-0">
                <div class="card-body">
            
                    <div class="mt-1">
            
                        <?php
                        $practiceName = trim($lead['practice_name'] ?? '');
                        $initials = '—';
                        
                        if ($practiceName !== '') {
                            $words = preg_split('/\s+/', $practiceName);
                            $initials = strtoupper(substr($words[0], 0, 1));
                            if (isset($words[1])) {
                                $initials .= strtoupper(substr($words[1], 0, 1));
                            }
                        }
                        
                        $isVerified   = (int)($lead['data_verified'] ?? 0) === 1;
                        ?>
                        
                        <h1 class="h6 header-title mb-2 d-flex align-items-center gap-2">
                        
                            <span class="avatar-initials bg-primary">
                                <?= html_escape($initials); ?>
                            </span>
                        
                            <span>
                                <?= html_escape($practiceName ?: '—'); ?>
                            </span>
                        
                            <?php if ($isVerified): ?>
                                <span class="pill pill-success d-flex align-items-center gap-1">
                                    <i class="ti ti-shield-check"></i>
                                    Verified
                                </span>
                                <?php else: ?>
                                <span class="pill pill-warning">
                                    <i class="ti ti-alert-triangle"></i> Not Verified
                                </span>
                                <?php endif; ?>
                        
                        </h1>
                            

                        <div class="info-value mt-2">
                            <span class="badge bg-light-info capital"><b>Quality:</b>  <?= html_escape($lead['lead_quality'] ?? '—'); ?></span>
                            <i class="ti ti-dots-vertical mx-1"></i>
                            <span class="badge bg-light-success capital"><b>Source:</b>  <?= html_escape($lead['lead_source'] ?? '—'); ?></span>
                            <i class="ti ti-dots-vertical mx-1"></i>
                            <span class="badge bg-light-primary capital"><b>Score:</b>  <?= html_escape($lead['lead_score'] ?? '—'); ?></span>
                        </div>
            
                        <div class="info-value mt-2"><i class="ti ti-map-pin text-danger"></i>
                            <?= html_escape($lead['address'] ?? '') ?>
                            <?= html_escape($lead['city'] ?? '') ?><?= !empty($lead['city']) ? ',' : '' ?>
                            <?= html_escape($lead['state'] ?? '') ?>
                            <?= html_escape($lead['zip_code'] ?? '') ?>
                            <?= html_escape($lead['country'] ?? '') ?>
                        </div>
            
                        <div class="app-divider-v dashed my-2"></div>
            
                        <div class="d-flex align-items-center gap-2 small">
                        
                        Notes: <span class="small text-muted"><?= html_escape($lead['internal_notes']) ?></span>

                        </div>

                    </div>
            
                </div>
            </div>
            
            <div class="section-card">
                <div class="card-header section-title bg-primary">
                <i class="ti ti-address-book"></i> Lead Contact
                </div>
                <div class="card-body pt-2 pb-2">

                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-user me-2"></i><span class="info-label">Full Name</span></div>
                        <div class="info-value"><?= html_escape($lead['contact_person'] ?? '—') ?></div>
                      </div>
        
                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-mail me-2"></i><span class="info-label">Email</span></div>
                        <div class="info-value"><?= html_escape($lead['contact_email'] ?? '—') ?></div>
                      </div>
        
                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-phone me-2"></i><span class="info-label">Phone</span></div>
                        <div class="info-value"><?= html_escape($lead['contact_phone'] ?? '—') ?></div>
                      </div>
        
                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-device-landline-phone me-2"></i><span class="info-label">Alternate Phone</span></div>
                        <div class="info-value"><?= html_escape($lead['alternate_phone'] ?? '—') ?></div>
                      </div>

                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-world me-2"></i><span class="info-label">Website</span></div>
                        <div class="info-value"><?= html_escape($lead['website'] ?? '—') ?></div>
                      </div>
                      
                </div>
            </div>

            <div class="section-card">
                <div class="card-header section-title bg-primary">
                <i class="ti ti-address-book"></i> Lead Contact
                </div>
                <div class="card-body pt-2 pb-2">

                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-user me-2"></i><span class="info-label">Full Name</span></div>
                        <div class="info-value"><?= html_escape($lead['contact_person'] ?? '—') ?></div>
                      </div>
        
                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-mail me-2"></i><span class="info-label">Email</span></div>
                        <div class="info-value"><?= html_escape($lead['contact_email'] ?? '—') ?></div>
                      </div>
        
                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-phone me-2"></i><span class="info-label">Phone</span></div>
                        <div class="info-value"><?= html_escape($lead['contact_phone'] ?? '—') ?></div>
                      </div>
        
                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-device-landline-phone me-2"></i><span class="info-label">Alternate Phone</span></div>
                        <div class="info-value"><?= html_escape($lead['alternate_phone'] ?? '—') ?></div>
                      </div>

                      <div class="info-row">
                        <div class="info-icon"><i class="ti ti-world me-2"></i><span class="info-label">Website</span></div>
                        <div class="info-value"><?= html_escape($lead['website'] ?? '—') ?></div>
                      </div>
                      
                </div>
            </div>
            
        </div>

        <!-- Right: Tabs Profile -->
        <div class="col-md-7">
            <!-- Tabbed Main Info -->
            <div class="card">
              <div class="card-body">
                <ul class="nav nav-tabs tab-primary bg-primary p-1 mb-2 small" id="profileTabs" role="tablist" style="--bs-nav-link-padding-y: 0.25rem; --bs-nav-link-padding-x: 0.5rem; font-size: 0.85rem;">

                  <li class="nav-item" role="presentation">
                    <button class="nav-link active py-1 px-2" id="leaddetails-tab" data-bs-toggle="tab"
                     data-bs-target="#leaddetails" type="button" role="tab" aria-controls="leaddetails"
                     aria-selected="false"><i class="ti ti-list-details me-1"></i>Lead Details</button>
                  </li>
                  
                  <li class="nav-item" role="presentation">
                    <button class="nav-link py-1 px-2" id="leadpipeline-tab" data-bs-toggle="tab"
                     data-bs-target="#leadpipeline" type="button" role="tab" aria-controls="leadpipeline"
                     aria-selected="false"><i class="ti ti-timeline-event me-1"></i>Pipeline</button>
                  </li>

                  <li class="nav-item" role="presentation">
                    <button class="nav-link py-1 px-2" id="proposals-tab" data-bs-toggle="tab"
                     data-bs-target="#proposals" type="button" role="tab" aria-controls="proposals"
                     aria-selected="false"><i class="ti ti-file-like me-1"></i>Proposals</button>
                  </li>
                  
                  <li class="nav-item" role="presentation">
                    <button class="nav-link py-1 px-2" id="activity-tab" data-bs-toggle="tab"
                     data-bs-target="#activity" type="button" role="tab" aria-controls="activity"
                     aria-selected="false"><i class="ti ti-activity me-1"></i>Activity</button>
                  </li>
                  
                </ul>
                
                <div class="tab-content small" id="profileTabsContent">
                  
                  <!-- Employee Profile Tabs -->
                  <?php $CI =& get_instance(); ?>
                  <?php echo $CI->load->view('leads/tabs/lead_details', [], true); ?>
                  <?php echo $CI->load->view('leads/tabs/activities', [], true); ?>
                  <?php echo $CI->load->view('leads/tabs/lead_pipeline', [], true); ?> 
                  <?php echo $CI->load->view('leads/tabs/proposals', [], true); ?>

                </div>
              </div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
  // Optional: hook your existing edit modal logic here
  const btn = document.getElementById('btnEditLead');
  if (!btn) return;

  btn.addEventListener('click', function () {
    const leadId = this.getAttribute('data-lead-id');
    // If you already have a modal in your CRM leads list, reuse it here.
    // Example endpoint you already have: crm/leads/ajax_get/{id}
    // You can trigger the same modal + populate fields via AJAX.
    window.location.href = "<?= site_url('crm/leads'); ?>?edit=" + encodeURIComponent(leadId);
  });
})();
</script>