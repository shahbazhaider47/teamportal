<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php $CI =& get_instance(); ?>

<?php
$groupId   = (int)($group['id'] ?? 0);
$status    = strtolower(trim((string)($group['status'] ?? 'inactive')));
$isActive  = ($status === 'active');
$isInactive = ($status === 'inactive');
$isOnHold   = in_array($status, ['hold', 'on-hold', 'on hold'], true);
$isTerminated = ($status === 'terminated');
$isArchived   = ($status === 'archived');

$canEdit        = staff_can('client_edit', 'crm');
$canDelete      = staff_can('client_delete', 'crm');
$canViewClients = staff_can('client_view', 'crm') || staff_can('view', 'crm');

$totalClients    = is_array($clients) ? count($clients) : 0;
$activeClients   = 0;
$inactiveClients = 0;

if (!empty($clients)) {
    foreach ($clients as $c) {
        if ((int)($c['is_active'] ?? 0) === 1) {
            $activeClients++;
        } else {
            $inactiveClients++;
        }
    }
}

$val = function ($v, $fallback = '—') {
    $v = is_string($v) ? trim($v) : $v;
    return ($v !== '' && $v !== null) ? $v : $fallback;
};

$groupName   = $val($group['group_name'] ?? null);
$companyName = $val($group['company_name'] ?? null);

$words    = preg_split('/\s+/', $groupName);
$initials = strtoupper(substr($words[0] ?? 'G', 0, 1));
if (isset($words[1])) {
    $initials .= strtoupper(substr($words[1], 0, 1));
}
?>

<div class="container-fluid">

  <div class="crm-page-header mb-3">
    <div class="crm-page-icon me-3">
      <a href="<?= site_url('crm/groups') ?>" class="fs-semibold text-decoration-none" title="Go back to groups list">
        <i class="ti ti-arrow-back-up me-2"></i>
      </a>
    </div>

    <div class="flex-grow-1">
      <div class="crm-page-title"><?= html_escape($groupName) ?></div>
      <div class="crm-page-sub">
        This Group is managed for
        <span class="fw-semibold"><?= html_escape($companyName) ?></span>
      </div>
    </div>

    <div class="ms-auto d-flex gap-2">

      <?php if ($canEdit): ?>
        <button class="btn btn-light-primary btn-header"
                data-bs-toggle="modal"
                data-bs-target="#crmGroupModal"
                data-modal-url="<?= site_url('crm/group_edit_modal/' . $groupId) ?>">
          <i class="ti ti-edit"></i>
          <span>Edit</span>
        </button>
      <?php endif; ?>

      <div class="btn-divider mt-1"></div>

      <div class="dropdown">
        <button class="btn btn-light-primary btn-header dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="ti ti-dots-vertical"></i>
        </button>

        <div class="dropdown-menu dropdown-menu-end app-page-header__menu">
          <a class="dropdown-item" href="#" onclick="addClientToGroup(<?= $groupId ?>)">
            <i class="ti ti-user-plus"></i> Add Client
          </a>

          <a class="dropdown-item" href="#" onclick="logActivity('call')">
            <i class="ti ti-phone"></i> Log a Call
          </a>

          <a class="dropdown-item" href="#" onclick="logActivity('email')">
            <i class="ti ti-mail"></i> Email Group Contact
          </a>

          <a class="dropdown-item" href="#" onclick="createGroupInvoice()">
            <i class="ti ti-file-invoice"></i> Create Group Invoice
          </a>

          <div class="dropdown-divider"></div>

          <?php if ($canDelete): ?>
            <button type="button"
                    class="dropdown-item text-danger"
                    onclick="deleteGroup(<?= $groupId ?>)">
              <i class="ti ti-trash"></i> Delete Group
            </button>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>

  <!-- Hero -->
  <div class="crm-card">
    <div class="hero-inner">
      <div class="avatar"><?= html_escape($initials) ?></div>

      <div class="hero-info">
        <h2 class="hero-name">
          <?= html_escape($companyName) ?>

          <?php if ($isActive): ?>
            <span class="badge badge-active">Active</span>
          <?php elseif ($isInactive): ?>
            <span class="badge badge-inactive">Inactive</span>
          <?php endif; ?>
        </h2>

        <div class="badge-row">
          <span class="badge badge-type">
            <i class="ti ti-users-group" style="font-size:11px"></i> Client Group
          </span>

          <?php if (!empty($group['contract_date'])): ?>
            <span class="badge badge-pill">
              <i class="ti ti-signature"></i>
              Contract: <?= html_escape($val($group['contract_date'] ?? null)) ?>
            </span>
          <?php endif; ?>

          <?php if (!empty($group['website'])): ?>
            <span class="badge badge-pill">
              <i class="ti ti-world text-primary"></i>
              <a href="<?= prep_url($group['website']) ?>" target="_blank" class="text-decoration-none">
                Website
              </a>
            </span>
          <?php endif; ?>
        </div>
        
      </div>
    </div>

    <!-- KPI Strip -->
    <div class="kpi-strip">
      <div class="kpi">
        <span class="kpi-label">Total Clients</span>
        <span class="kpi-value"><?= $totalClients ?></span>
        <span class="kpi-sub">All assigned</span>
      </div>

      <div class="kpi">
        <span class="kpi-label">Active Clients</span>
        <span class="kpi-value kpi-value-success"><?= $activeClients ?></span>
        <span class="kpi-sub">Currently active</span>
      </div>

      <div class="kpi">
        <span class="kpi-label">Inactive Clients</span>
        <span class="kpi-value"><?= $inactiveClients ?></span>
        <span class="kpi-sub">Paused or ended</span>
      </div>

      <div class="kpi">
        <span class="kpi-label">Contact Person</span>
        <span class="kpi-value"><?= html_escape($val($group['contact_person'] ?? null)) ?></span>
        <span class="kpi-sub">Primary contact</span>
      </div>

      <div class="kpi">
        <span class="kpi-label">Group Status</span>
        <span class="kpi-value"><?= html_escape(ucfirst(str_replace('-', ' ', $status))) ?></span>
        <span class="kpi-sub">Current standing</span>
      </div>

      <div class="kpi">
        <span class="kpi-label">Contract Date</span>
        <span class="kpi-value"><?= html_escape($val($group['contract_date'] ?? null)) ?></span>
        <span class="kpi-sub">Agreement signed</span>
      </div>
    </div>

    <div class="col-md-12">
      <div class="crm-profile-wrap mt-4">
        <ul class="crm-tab-nav" id="groupProfileTabs" role="tablist">

          <li class="crm-tab-item" role="presentation">
            <button class="crm-tab-btn active" id="group-details-tab" data-bs-toggle="tab" data-bs-target="#group-details-pane"
                    type="button" role="tab" aria-controls="group-details-pane" aria-selected="true">
              <i class="ti ti-list-details"></i>
              Group Details
            </button>
          </li>

          <li class="crm-tab-item" role="presentation">
            <button class="crm-tab-btn" id="group-clients-tab" data-bs-toggle="tab" data-bs-target="#group-clients-pane"
                    type="button" role="tab" aria-controls="group-clients-pane" aria-selected="false">
              <i class="ti ti-users"></i>
              Clients
              <span class="crm-tab-badge"><?= $totalClients ?></span>
            </button>
          </li>

          <li class="crm-tab-item" role="presentation">
            <button class="crm-tab-btn" id="group-invoices-tab" data-bs-toggle="tab" data-bs-target="#group-invoices-pane"
                    type="button" role="tab" aria-controls="group-invoices-pane" aria-selected="false">
              <i class="ti ti-file-invoice"></i>
              Invoices
              <span class="crm-tab-badge">3</span>
            </button>
          </li>

          <li class="crm-tab-item" role="presentation">
            <button class="crm-tab-btn" id="group-payments-tab" data-bs-toggle="tab" data-bs-target="#group-payments-pane"
                    type="button" role="tab" aria-controls="group-payments-pane" aria-selected="false">
              <i class="ti ti-cash"></i>
              Payments
            </button>
          </li>

          <li class="crm-tab-item" role="presentation">
            <button class="crm-tab-btn" id="group-activity-tab" data-bs-toggle="tab" data-bs-target="#group-activity-pane"
                    type="button" role="tab" aria-controls="group-activity-pane" aria-selected="false">
              <i class="ti ti-activity"></i>
              Activity
              <span class="crm-tab-badge">4</span>
            </button>
          </li>

        </ul>

        <div class="crm-tab-content" id="groupProfileTabsContent">

          <!-- Group Details -->
          <div class="tab-pane fade show active" id="group-details-pane" role="tabpanel"
               aria-labelledby="group-details-tab" tabindex="0">

            <div class="row g-3">
              <div class="col-lg-6">
                <div class="audit-section h-100">
                  <div class="audit-section-header">
                    <span><i class="ti ti-users"></i> Group Details</span>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-users-group"></i></div>
                    <div>
                      <div class="audit-label">Group Name</div>
                      <div class="audit-value"><?= html_escape($groupName) ?></div>
                    </div>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-building"></i></div>
                    <div>
                      <div class="audit-label">Company Name</div>
                      <div class="audit-value"><?= html_escape($companyName) ?></div>
                    </div>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-address-book"></i></div>
                    <div>
                      <div class="audit-label">Contact Person</div>
                      <div class="audit-value"><?= html_escape($val($group['contact_person'] ?? null)) ?></div>
                    </div>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-mail"></i></div>
                    <div>
                      <div class="audit-label">Contact Email</div>
                      <div class="audit-value"><?= html_escape($val($group['contact_email'] ?? null)) ?></div>
                    </div>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-phone"></i></div>
                    <div>
                      <div class="audit-label">Contact Phone</div>
                      <div class="audit-value"><?= html_escape($val($group['contact_phone'] ?? null)) ?></div>
                    </div>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-world"></i></div>
                    <div>
                      <div class="audit-label">Website</div>
                      <div class="audit-value"><?= html_escape($val($group['website'] ?? null)) ?></div>
                    </div>
                  </div>

                  <div class="audit-row">
                    <div class="audit-icon"><i class="ti ti-calendar-event"></i></div>
                    <div>
                      <div class="audit-label">Contract Date</div>
                      <div class="audit-value"><?= html_escape($val($group['contract_date'] ?? null)) ?></div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-6">
                <div class="audit-section h-100">
                  <div class="audit-section-header">
                    <span><i class="ti ti-chart-bar"></i> Group Summary</span>
                  </div>

                  <div class="detail-grid">
                    <div class="detail-cell">
                      <div class="dc-label">Total Clients</div>
                      <div class="dc-value"><?= $totalClients ?></div>
                    </div>

                    <div class="detail-cell">
                      <div class="dc-label">Active Clients</div>
                      <div class="dc-value"><?= $activeClients ?></div>
                    </div>

                    <div class="detail-cell">
                      <div class="dc-label">Inactive Clients</div>
                      <div class="dc-value"><?= $inactiveClients ?></div>
                    </div>

                    <div class="detail-cell">
                      <div class="dc-label">Status</div>
                      <div class="dc-value"><?= html_escape(ucfirst(str_replace('-', ' ', $status))) ?></div>
                    </div>

                    <div class="detail-cell full-width">
                      <div class="dc-label">Internal Summary</div>
                      <div class="dc-value">
                        <?= html_escape($groupName) ?> is currently managing <?= $totalClients ?> client<?= $totalClients !== 1 ? 's' : '' ?> under this group record.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          <!-- Clients -->
          <div class="tab-pane fade" id="group-clients-pane" role="tabpanel"
               aria-labelledby="group-clients-tab" tabindex="0">

            <?php if (!$canViewClients): ?>
              <div class="placeholder-content">
                <i class="ti ti-lock"></i>
                <h4>Access Restricted</h4>
                <p>You don't have permission to view clients in this group.</p>
              </div>

            <?php elseif (empty($clients)): ?>
              <div class="placeholder-content">
                <i class="ti ti-users-off"></i>
                <h4>No Clients Found</h4>
                <p>No clients are assigned to this group yet.</p>
              </div>

            <?php else: ?>
              <div class="crm-card p-0">
                <div class="table-responsive crm-table">
                  <table class="table small table-sm table-bottom-border align-middle mb-2 table-box-hover">
                    <thead class="bg-light-primary">
                      <tr>
                        <th>Client</th>
                        <th>Location</th>
                        <th>Billing</th>
                        <th>Contract</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($clients as $c): ?>
                        <?php
                        $cId      = (int)($c['id'] ?? 0);
                        $cActive  = (int)($c['is_active'] ?? 0) === 1;
                        $legal    = trim((string)($c['practice_legal_name'] ?? ''));
                        $pname    = trim((string)($c['practice_name'] ?? ''));
                        $dispName = $legal !== '' ? $legal : ($pname !== '' ? $pname : '—');
                        $city     = trim((string)($c['city'] ?? ''));
                        $state    = trim((string)($c['state'] ?? ''));
                        $zip      = trim((string)($c['zip_code'] ?? ''));
                        $bModel   = trim((string)($c['billing_model'] ?? ''));
                        $rateP    = trim((string)($c['rate_percent'] ?? ''));
                        $rateF    = trim((string)($c['rate_flat'] ?? ''));
                        $start    = trim((string)($c['contract_start_date'] ?? ''));
                        $end      = trim((string)($c['contract_end_date'] ?? ''));
                        ?>
                        <tr>
                          <td class="small">
                            <div class="fw-semibold mb-1">
                              <?php if ($canViewClients && $cId > 0): ?>
                                <a href="<?= site_url('crm/client_view/' . $cId) ?>" class="text-primary" target="_blank" rel="noopener">
                                  <?= html_escape($dispName) ?>
                                </a>
                              <?php else: ?>
                                <span class="text-dark"><?= html_escape($dispName) ?></span>
                              <?php endif; ?>
                            </div>

                            <div class="x-small text-muted">
                              <?php if (!empty($c['client_code'])): ?>
                                <span><i class="ti ti-hash text-muted me-1"></i><?= html_escape($c['client_code']) ?></span>
                              <?php endif; ?>

                              <?php if (!empty($c['specialty'])): ?>
                                <span class="ms-2"><i class="ti ti-stethoscope text-info me-1"></i><?= html_escape($c['specialty']) ?></span>
                              <?php endif; ?>
                            </div>
                          </td>

                          <td class="small">
                            <?php if ($city !== '' || $state !== ''): ?>
                              <div><?= html_escape($city ?: '—') ?><?= $state ? ', ' . html_escape($state) : '' ?></div>
                              <?php if ($zip): ?>
                                <div class="x-small text-muted mt-1">
                                  <i class="ti ti-map-pin text-danger me-1"></i><?= html_escape($zip) ?>
                                </div>
                              <?php endif; ?>
                            <?php else: ?>
                              <span class="text-muted">—</span>
                            <?php endif; ?>
                          </td>

                          <td class="small">
                            <div class="fw-semibold text-dark"><?= $bModel ? html_escape(ucfirst($bModel)) : '—' ?></div>
                            <div class="x-small text-muted mt-1">
                              <?php if ($rateP !== ''): ?>
                                <span><i class="ti ti-percentage me-1"></i><?= html_escape($rateP) ?>%</span>
                              <?php endif; ?>
                              <?php if ($rateF !== ''): ?>
                                <span class="ms-2"><i class="ti ti-currency-dollar me-1"></i><?= html_escape($rateF) ?></span>
                              <?php endif; ?>
                            </div>
                          </td>

                          <td class="small">
                            <?php if ($start || $end): ?>
                              <?php if ($start): ?>
                                <div class="d-flex align-items-center gap-1 text-muted">
                                  <i class="ti ti-calendar-event text-success" style="font-size:13px;"></i>
                                  <span><?= html_escape($start) ?></span>
                                </div>
                              <?php endif; ?>
                              <?php if ($end): ?>
                                <div class="d-flex align-items-center gap-1 text-muted mt-1">
                                  <i class="ti ti-calendar-off text-danger" style="font-size:13px;"></i>
                                  <span><?= html_escape($end) ?></span>
                                </div>
                              <?php endif; ?>
                            <?php else: ?>
                              <span class="text-muted">—</span>
                            <?php endif; ?>
                          </td>

                          <td>
                            <?php if ($cActive): ?>
                              <span class="badge badge-active"><span class="badge-dot-green"></span> Active</span>
                            <?php else: ?>
                              <span class="badge badge-inactive">Inactive</span>
                            <?php endif; ?>
                          </td>

                          <td class="text-end">
                            <?php if ($canViewClients && $cId > 0): ?>
                              <a href="<?= site_url('crm/client_view/' . $cId) ?>" class="btn btn-light-primary btn-header" target="_blank" rel="noopener">
                                <i class="ti ti-eye"></i> View
                              </a>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            <?php endif; ?>

          </div>

          <!-- Invoices -->
          <div class="tab-pane fade" id="group-invoices-pane" role="tabpanel"
               aria-labelledby="group-invoices-tab" tabindex="0">

            <div class="crm-card p-0">
              <div class="table-responsive crm-table">
                <table class="table small table-sm table-bottom-border align-middle mb-2 table-box-hover">
                  <thead class="bg-light-primary">
                    <tr>
                      <th>Invoice #</th>
                      <th>Description</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Due Date</th>
                      <th class="text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="small">#GRP-2026-003</td>
                      <td class="small">
                        <div class="fw-semibold">March 2026 — Group Billing</div>
                        <div class="x-small text-muted"><?= $totalClients ?> clients</div>
                      </td>
                      <td class="small fw-semibold">$<?= number_format($totalClients * 1533.33, 2) ?></td>
                      <td><span class="badge badge-hold">Pending</span></td>
                      <td class="small">Mar 15, 2026</td>
                      <td class="text-end">
                        <button class="btn btn-light-primary btn-header"><i class="ti ti-eye"></i></button>
                      </td>
                    </tr>

                    <tr>
                      <td class="small">#GRP-2026-002</td>
                      <td class="small">
                        <div class="fw-semibold">February 2026 — Group Billing</div>
                        <div class="x-small text-muted"><?= $totalClients ?> clients</div>
                      </td>
                      <td class="small fw-semibold">$<?= number_format($totalClients * 1533.33, 2) ?></td>
                      <td><span class="badge badge-active"><span class="badge-dot-green"></span> Paid</span></td>
                      <td class="small">Feb 15, 2026</td>
                      <td class="text-end">
                        <button class="btn btn-light-primary btn-header"><i class="ti ti-eye"></i></button>
                      </td>
                    </tr>

                    <tr>
                      <td class="small">#GRP-2026-001</td>
                      <td class="small">
                        <div class="fw-semibold">January 2026 — Group Billing</div>
                        <div class="x-small text-muted"><?= $totalClients ?> clients</div>
                      </td>
                      <td class="small fw-semibold">$<?= number_format($totalClients * 1533.33, 2) ?></td>
                      <td><span class="badge badge-active"><span class="badge-dot-green"></span> Paid</span></td>
                      <td class="small">Jan 15, 2026</td>
                      <td class="text-end">
                        <button class="btn btn-light-primary btn-header"><i class="ti ti-eye"></i></button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>

          <!-- Payments -->
          <div class="tab-pane fade" id="group-payments-pane" role="tabpanel"
               aria-labelledby="group-payments-tab" tabindex="0">

            <div class="crm-card p-0">
              <div class="table-responsive crm-table">
                <table class="table small table-sm table-bottom-border align-middle mb-2 table-box-hover">
                  <thead class="bg-light-primary">
                    <tr>
                      <th>Reference</th>
                      <th>Invoice</th>
                      <th>Amount</th>
                      <th>Method</th>
                      <th>Date</th>
                      <th>Received By</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="small">ACH-990182</td>
                      <td class="small text-primary">#GRP-2026-002</td>
                      <td class="small fw-semibold text-success">$<?= number_format($totalClients * 1533.33, 2) ?></td>
                      <td class="small"><i class="ti ti-building-bank me-1"></i> ACH Transfer</td>
                      <td class="small">Feb 12, 2026</td>
                      <td class="small">System</td>
                    </tr>

                    <tr>
                      <td class="small">ACH-881044</td>
                      <td class="small text-primary">#GRP-2026-001</td>
                      <td class="small fw-semibold text-success">$<?= number_format($totalClients * 1533.33, 2) ?></td>
                      <td class="small"><i class="ti ti-building-bank me-1"></i> ACH Transfer</td>
                      <td class="small">Jan 13, 2026</td>
                      <td class="small">System</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>

          <!-- Activity -->
          <div class="tab-pane fade" id="group-activity-pane" role="tabpanel"
               aria-labelledby="group-activity-tab" tabindex="0">

            <div class="audit-section">
              <div class="audit-row">
                <div class="audit-icon" style="background: #e0f2fe; color: #0284c7;"><i class="ti ti-file-invoice"></i></div>
                <div style="flex:1;">
                  <div class="d-flex justify-content-between mb-1">
                    <span class="fw-semibold">Group Invoice #GRP-2026-003 Generated</span>
                    <span class="x-small text-muted">Mar 1, 2026 · 8:00 AM</span>
                  </div>
                  <div class="small text-muted mb-1">
                    Monthly group invoice generated for <?= $totalClients ?> clients. Total: $<?= number_format($totalClients * 1533.33, 2) ?>. Due: Mar 15, 2026.
                  </div>
                  <div class="x-small text-muted"><i class="ti ti-bolt"></i> System — Auto-billing</div>
                </div>
              </div>

              <div class="audit-row">
                <div class="audit-icon" style="background: #dcfce7; color: #16a34a;"><i class="ti ti-phone"></i></div>
                <div style="flex:1;">
                  <div class="d-flex justify-content-between mb-1">
                    <span class="fw-semibold">Outbound Call — 18 min</span>
                    <span class="x-small text-muted">Feb 22, 2026 · 10:30 AM</span>
                  </div>
                  <div class="small text-muted mb-1">
                    Monthly check-in call with group contact <?= html_escape($val($group['contact_person'] ?? 'the group contact')) ?>. Discussed performance across all <?= $totalClients ?> clients.
                  </div>
                  <div class="x-small text-muted"><i class="ti ti-user"></i> James Carter · <span class="text-success">Positive</span></div>
                </div>
              </div>

              <div class="audit-row">
                <div class="audit-icon" style="background: #dcfce7; color: #16a34a;"><i class="ti ti-circle-check"></i></div>
                <div style="flex:1;">
                  <div class="d-flex justify-content-between mb-1">
                    <span class="fw-semibold text-success">Payment Received — #GRP-2026-002</span>
                    <span class="x-small text-muted">Feb 12, 2026 · 3:15 PM</span>
                  </div>
                  <div class="small text-muted mb-1">
                    ACH payment of $<?= number_format($totalClients * 1533.33, 2) ?> received for February group invoice. Reference: ACH-990182.
                  </div>
                  <div class="x-small text-muted"><i class="ti ti-bolt"></i> System — Payment received</div>
                </div>
              </div>

              <div class="audit-row">
                <div class="audit-icon" style="background: #fef9c3; color: #854d0e;"><i class="ti ti-notes"></i></div>
                <div style="flex:1;">
                  <div class="d-flex justify-content-between mb-1">
                    <span class="fw-semibold">Internal Note</span>
                    <span class="x-small text-muted">Jan 20, 2026 · 9:00 AM</span>
                  </div>
                  <div class="small text-muted mb-1">
                    Group contact mentioned they may add 2 more practices to the group by Q2 2026. Flagged for growth tracking.
                  </div>
                  <div class="x-small text-muted"><i class="ti ti-user"></i> James Carter</div>
                </div>
              </div>

              <div class="audit-row">
                <div class="audit-icon" style="background: #e0f2fe; color: #0284c7;"><i class="ti ti-network"></i></div>
                <div style="flex:1;">
                  <div class="d-flex justify-content-between mb-1">
                    <span class="fw-semibold text-primary">Group Account Created</span>
                    <span class="x-small text-muted">Jan 5, 2026 · 11:44 AM</span>
                  </div>
                  <div class="small text-muted mb-1">
                    Group <strong><?= html_escape($groupName) ?></strong> created and activated. <?= $totalClients ?> client<?= $totalClients !== 1 ? 's' : '' ?> assigned at setup.
                  </div>
                  <div class="x-small text-muted"><i class="ti ti-user"></i> James Carter</div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>

  </div>

</div>

<div class="modal fade" id="crmGroupModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-top">
    <div class="modal-content">
      <div class="modal-body p-0" id="crmGroupModalBody">
        <div class="p-4 text-muted">Loading…</div>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  document.addEventListener('click', function(e) {
    const btn = e.target.closest('[data-modal-url]');
    if (!btn) return;

    const url  = btn.getAttribute('data-modal-url');
    const body = document.getElementById('crmGroupModalBody');
    if (!url || !body) return;

    body.innerHTML = '<div class="p-4 text-muted">Loading…</div>';

    fetch(url, { credentials: 'same-origin' })
      .then(r => r.text())
      .then(html => body.innerHTML = html)
      .catch(() => body.innerHTML = '<div class="p-4 text-danger">Failed to load.</div>');
  });

  window.addClientToGroup   = id => { if (confirm('Add client to this group?')) console.log('[CRM] Add client to group', id); };
  window.createGroupInvoice = () => console.log('[CRM] Create group invoice');
  window.generateReport     = () => console.log('[CRM] Generate report');
  window.logActivity        = type => console.log('[CRM] Log:', type);
  window.deleteGroup        = id => {
    if (confirm('Delete this group? This action cannot be undone.')) {
      window.location.href = '<?= site_url('crm/groups') ?>';
    }
  };
})();
</script>