<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<style>
.crm-group {
    min-width: 250px;
    max-width: 250px;
    font-size: 12px !important
}
.input-group-text{
    font-size: 12px !important
}
</style>

<div class="container-fluid">
<?= form_open(site_url('crm/settings'), ['method' => 'post']) ?>
<div class="crm-page-header mb-3 d-flex align-items-center">

  <div class="crm-page-icon me-3">
    <i class="ti ti-settings"></i>
  </div>

  <div class="flex-grow-1">
    <div class="crm-page-title"><?= $page_title ?></div>
    <div class="crm-page-sub">Configure CRM defaults for leads, proposals, contracts, clients, and data quality.</div>
  </div>

  <div class="ms-auto">
    <button type="submit" class="btn btn-primary btn-header">
      <i class="ti ti-device-floppy me-1"></i> Save Settings
    </button>
  </div>

</div>

  <div class="row app-form">

    <!-- ══════════════════════════════════════════════════════
         COLUMN 1
    ══════════════════════════════════════════════════════ -->
    <div class="col-md-6">

      <!-- ── Leads ─────────────────────────────────────── -->
      <div class="card card-body border-bottom pb-3 mb-4">
        <div class="card-header bg-light-primary py-2 mb-3">
          <h6 class="mb-0 text-muted"><i class="ti ti-target-arrow me-2"></i>Lead Defaults</h6>
        </div>

        <!-- crm_leads.lead_status default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Lead Status Done</span>
            <select class="form-select" name="settings[crm_default_lead_status]">
              <?php
              $dls = $existing_data['crm_default_lead_status'] ?? 'new';
              ?>
                <?php foreach (lead_status_dropdown() as $value => $label): ?>
            <option value="<?= html_escape($value) ?>"
                <?= (
                    set_value('lead_status') == $value
                    || (
                        empty(set_value('lead_status')) &&
                        (
                            (!empty($lead['lead_status']) && $lead['lead_status'] == $value)
                            || (empty($lead['lead_status']) && crm_setting('crm_default_lead_status', 'new') == $value)
                        )
                    )
                ) ? 'selected' : '' ?>>
                <?= html_escape($label) ?>
            </option>
                <?php endforeach; ?>
            </select>
          </div>
        </div>
        
        <!-- crm_leads.forecast_probability default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Forecast Probability</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_forecast_probability]"
                   min="0" max="100"
                   value="<?= e($existing_data['crm_default_forecast_probability'] ?? 25) ?>">
            <span class="input-group-text">%</span>
          </div>
        </div>


        <!-- crm_leads.next_followup_date offset -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Follow-up (Days) Done</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_followup_days]"
                   min="1"
                   value="<?= e($existing_data['crm_default_followup_days'] ?? 3) ?>">
            <span class="input-group-text">days after creation</span>
          </div>
        </div>

        <!-- Stale threshold — used against crm_leads.last_contact_date -->
        <div class="mb-3">
          <div class="input-group">
            <span class="input-group-text crm-group">Flag & Stale Lead Threshold Done</span>
            <input type="number" class="form-control"
                   name="settings[crm_flag_stale_lead_days]"
                   min="1"
                   value="<?= e($existing_data['crm_flag_stale_lead_days'] ?? 14) ?>">
            <span class="input-group-text">days without contact</span>
          </div>
        </div>

        <!-- Lead Automation toggles -->
        <div class="card card-body mb-0">
          <label class="form-label fw-bold mb-0 text-primary">Lead Automation</label>
          <hr class="mt-1">

          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" role="switch"
                   name="settings[crm_auto_assign_new_leads]" value="1"
                   <?= !empty($existing_data['crm_auto_assign_new_leads']) ? 'checked' : '' ?>>
            <label class="form-check-label">Auto-assign New Leads Done</label>
            <small class="text-muted d-block">Sets <code>crm_leads.assigned_to</code> automatically on creation.</small>
          </div>

          <div class="mb-2" id="wrap_default_assignee">
            <div class="input-group">
              <span class="input-group-text crm-group">Default Assignee</span>
                <select name="settings[crm_default_assignee_id]"
                        class="form-select js-assign-select">
                
                    <option value="">— None —</option>
                
                    <?php if (!empty($users)): foreach ($users as $u): ?>
                        <?php
                            $avatarSrc = user_avatar_url(
                                !empty($u['profile_image']) ? $u['profile_image'] : (int)$u['id']
                            );
                        ?>
                        <option value="<?= (int)$u['id'] ?>"
                                data-avatar="<?= html_escape($avatarSrc) ?>"
                            <?= ((int)($existing_data['crm_default_assignee_id'] ?? 0) === (int)$u['id']) ? 'selected' : '' ?>>
                            <?= html_escape($u['fullname'] ?? '') ?>
                        </option>
                    <?php endforeach; endif; ?>
                
                </select>
            </div>
            <small class="text-muted">Used when auto-assign is on</small>
          </div>

          <div class="form-check form-switch mb-0">
            <input class="form-check-input" type="checkbox" role="switch"
                   name="settings[crm_require_loss_reason]" value="1"
                   <?= !empty($existing_data['crm_require_loss_reason']) ? 'checked' : '' ?>>
            <label class="form-check-label">Require Loss Reason</label>
            <small class="text-muted d-block">Forces entry of <code>crm_leads.loss_reason</code> when marking Lost or Disqualified.</small>
          </div>

        </div>
      </div>

      <!-- ── Proposals ──────────────────────────────────── -->
      <div class="card card-body border-bottom pb-3 mb-4">
        <div class="card-header bg-light-primary py-2 mb-3">
          <h6 class="mb-0 text-muted"><i class="ti ti-file-description me-2"></i>Proposal Defaults</h6>
        </div>

        <!-- crm_proposals.status default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Proposal Status</span>
            <select class="form-select" name="settings[crm_default_proposal_status]">
              <?php $dps = $existing_data['crm_default_proposal_status'] ?? 'draft'; ?>
              <option value="draft"          <?= $dps === 'draft'          ? 'selected' : '' ?>>Draft</option>
              <option value="pending_review" <?= $dps === 'pending_review' ? 'selected' : '' ?>>Pending Review</option>
              <option value="sent"           <?= $dps === 'sent'           ? 'selected' : '' ?>>Sent</option>
            </select>
          </div>
        </div>

        <!-- crm_proposals.validity_days default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Validity (Days)</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_proposal_validity]"
                   min="1"
                   value="<?= e($existing_data['crm_default_proposal_validity'] ?? 30) ?>">
            <span class="input-group-text">days</span>
          </div>
        </div>

        <!-- crm_proposals.billing_cycle default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Billing Cycle</span>
            <select class="form-select" name="settings[crm_default_billing_cycle]">
              <?php $dbc = $existing_data['crm_default_billing_cycle'] ?? 'monthly'; ?>
              <option value="monthly"   <?= $dbc === 'monthly'   ? 'selected' : '' ?>>Monthly</option>
              <option value="weekly"    <?= $dbc === 'weekly'    ? 'selected' : '' ?>>Weekly</option>
              <option value="bi-weekly" <?= $dbc === 'bi-weekly' ? 'selected' : '' ?>>Bi-Weekly</option>
              <option value="quarterly" <?= $dbc === 'quarterly' ? 'selected' : '' ?>>Quarterly</option>
              <option value="annual"    <?= $dbc === 'annual'    ? 'selected' : '' ?>>Annual</option>
              <option value="custom"    <?= $dbc === 'custom'    ? 'selected' : '' ?>>Custom</option>
            </select>
          </div>
        </div>

        <!-- crm_proposals.tax_rate default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Tax Rate</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_tax_rate]"
                   min="0" max="100" step="0.01"
                   value="<?= e($existing_data['crm_default_tax_rate'] ?? 0) ?>">
            <span class="input-group-text">%</span>
          </div>
        </div>

        <!-- crm_proposals.payment_terms default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Payment Terms</span>
            <input type="text" class="form-control"
                   name="settings[crm_default_payment_terms]"
                   placeholder="e.g. Net 30"
                   value="<?= e($existing_data['crm_default_payment_terms'] ?? 'Net 30') ?>">
          </div>
        </div>

        <!-- Default terms & conditions text -->
        <div class="mb-0">
          <label class="form-label fw-semibold mb-1" style="font-size:13px;">Default Terms &amp; Conditions</label>
          <textarea class="form-control" rows="3"
                    name="settings[crm_default_terms_and_conditions]"
                    placeholder="Standard T&amp;C text pre-filled on every new proposal..."><?= html_escape($existing_data['crm_default_terms_and_conditions'] ?? '') ?></textarea>
        </div>

      </div>

    </div>

    <!-- ══════════════════════════════════════════════════════
         COLUMN 2
    ══════════════════════════════════════════════════════ -->
    <div class="col-md-6">

      <!-- ── Contracts ──────────────────────────────────── -->
      <div class="card card-body border-bottom pb-3 mb-4">
        <div class="card-header bg-light-primary py-2 mb-3">
          <h6 class="mb-0 text-muted"><i class="ti ti-file-certificate me-2"></i>Contract Defaults</h6>
        </div>

        <!-- crm_contracts.status default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Contract Status</span>
            <select class="form-select" name="settings[crm_default_contract_status]">
              <?php $dcs = $existing_data['crm_default_contract_status'] ?? 'draft'; ?>
              <option value="draft"             <?= $dcs === 'draft'             ? 'selected' : '' ?>>Draft</option>
              <option value="sent"              <?= $dcs === 'sent'              ? 'selected' : '' ?>>Sent</option>
              <option value="pending_signature" <?= $dcs === 'pending_signature' ? 'selected' : '' ?>>Pending Signature</option>
            </select>
          </div>
        </div>

        <!-- crm_contracts.billing_model default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Billing Model</span>
            <select class="form-select" name="settings[crm_default_billing_model]">
              <?php $dbm = $existing_data['crm_default_billing_model'] ?? 'percentage'; ?>
              <option value="percentage" <?= $dbm === 'percentage' ? 'selected' : '' ?>>Percentage</option>
              <option value="flat_fee"   <?= $dbm === 'flat_fee'   ? 'selected' : '' ?>>Flat Fee</option>
              <option value="custom"     <?= $dbm === 'custom'     ? 'selected' : '' ?>>Custom</option>
            </select>
          </div>
        </div>

        <!-- crm_contracts.invoice_frequency default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Invoice Frequency</span>
            <select class="form-select" name="settings[crm_default_invoice_frequency]">
              <?php $dif = $existing_data['crm_default_invoice_frequency'] ?? 'monthly'; ?>
              <option value="monthly"   <?= $dif === 'monthly'   ? 'selected' : '' ?>>Monthly</option>
              <option value="weekly"    <?= $dif === 'weekly'    ? 'selected' : '' ?>>Weekly</option>
              <option value="bi-weekly" <?= $dif === 'bi-weekly' ? 'selected' : '' ?>>Bi-Weekly</option>
              <option value="quarterly" <?= $dif === 'quarterly' ? 'selected' : '' ?>>Quarterly</option>
              <option value="annual"    <?= $dif === 'annual'    ? 'selected' : '' ?>>Annual</option>
              <option value="custom"    <?= $dif === 'custom'    ? 'selected' : '' ?>>Custom</option>
            </select>
          </div>
        </div>

        <!-- crm_contracts.payment_terms_days default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Payment Terms</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_payment_terms_days]"
                   min="1"
                   value="<?= e($existing_data['crm_default_payment_terms_days'] ?? 30) ?>">
            <span class="input-group-text">days (Net-X)</span>
          </div>
        </div>

        <!-- crm_contracts.auto_renew default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Auto Renew</span>
            <select class="form-select" name="settings[crm_default_auto_renew]">
              <?php $dar = (string)($existing_data['crm_default_auto_renew'] ?? '0'); ?>
              <option value="0" <?= $dar === '0' ? 'selected' : '' ?>>No</option>
              <option value="1" <?= $dar === '1' ? 'selected' : '' ?>>Yes</option>
            </select>
          </div>
        </div>

        <!-- crm_contracts.renewal_period default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Renewal Period</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_renewal_period]"
                   min="1"
                   value="<?= e($existing_data['crm_default_renewal_period'] ?? 12) ?>">
            <span class="input-group-text">months</span>
          </div>
        </div>

        <!-- crm_contracts.notice_period_days default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Notice Period</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_notice_period_days]"
                   min="1"
                   value="<?= e($existing_data['crm_default_notice_period_days'] ?? 30) ?>">
            <span class="input-group-text">days</span>
          </div>
        </div>

        <!-- crm_contracts.termination_notice_days default -->
        <div class="mb-0">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Termination Notice</span>
            <input type="number" class="form-control"
                   name="settings[crm_default_termination_notice_days]"
                   min="1"
                   value="<?= e($existing_data['crm_default_termination_notice_days'] ?? 30) ?>">
            <span class="input-group-text">days</span>
          </div>
        </div>

      </div>

      <!-- ── Clients ────────────────────────────────────── -->
      <div class="card card-body border-bottom pb-3 mb-4">
        <div class="card-header bg-light-primary py-2 mb-3">
          <h6 class="mb-0 text-muted"><i class="ti ti-building me-2"></i>Client Defaults</h6>
        </div>

        <!-- crm_clients.billing_model default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Billing Model</span>
            <select class="form-select" name="settings[crm_default_client_billing_model]">
              <?php $dcbm = $existing_data['crm_default_client_billing_model'] ?? 'percentage'; ?>
              <option value="percentage" <?= $dcbm === 'percentage' ? 'selected' : '' ?>>Percentage</option>
              <option value="flat"       <?= $dcbm === 'flat'       ? 'selected' : '' ?>>Flat Fee</option>
              <option value="custom"     <?= $dcbm === 'custom'     ? 'selected' : '' ?>>Custom</option>
            </select>
          </div>
        </div>

        <!-- crm_clients.invoice_frequency default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Invoice Frequency</span>
            <select class="form-select" name="settings[crm_default_client_invoice_freq]">
              <?php $dcif = $existing_data['crm_default_client_invoice_freq'] ?? 'monthly'; ?>
              <option value="monthly"   <?= $dcif === 'monthly'   ? 'selected' : '' ?>>Monthly</option>
              <option value="bi-weekly" <?= $dcif === 'bi-weekly' ? 'selected' : '' ?>>Bi-Weekly</option>
              <option value="weekly"    <?= $dcif === 'weekly'    ? 'selected' : '' ?>>Weekly</option>
              <option value="custom"    <?= $dcif === 'custom'    ? 'selected' : '' ?>>Custom</option>
            </select>
          </div>
        </div>

        <!-- crm_clients.client_status default -->
        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Default Client Status</span>
            <select class="form-select" name="settings[crm_default_client_status]">
              <?php $dstc = $existing_data['crm_default_client_status'] ?? 'active'; ?>
              <option value="active"     <?= $dstc === 'active'     ? 'selected' : '' ?>>Active</option>
              <option value="inactive"   <?= $dstc === 'inactive'   ? 'selected' : '' ?>>Inactive</option>
              <option value="on-hold"    <?= $dstc === 'on-hold'    ? 'selected' : '' ?>>On Hold</option>
              <option value="terminated" <?= $dstc === 'terminated' ? 'selected' : '' ?>>Terminated</option>
            </select>
          </div>
        </div>


      </div>

      <!-- ── Notifications ──────────────────────────────── -->
      <div class="card card-body border-bottom pb-3 mb-4">
        <div class="card-header bg-light-primary py-2 mb-3">
          <h6 class="mb-0 text-muted"><i class="ti ti-bell me-2"></i>Notifications</h6>
        </div>

        <div class="form-check form-switch mb-3">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_notify_on_assign]" value="1"
                 <?= !empty($existing_data['crm_notify_on_assign']) ? 'checked' : '' ?>>
          <label class="form-check-label">Notify on Lead Assignment</label>
          <small class="text-muted d-block">Email assignee when <code>crm_leads.assigned_to</code> is set or changed.</small>
        </div>

        <div class="form-check form-switch mb-3">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_notify_on_status_change]" value="1"
                 <?= !empty($existing_data['crm_notify_on_status_change']) ? 'checked' : '' ?>>
          <label class="form-check-label">Notify on Lead Status Change</label>
          <small class="text-muted d-block">Triggered when <code>crm_leads.lead_status</code> changes.</small>
        </div>

        <div class="form-check form-switch mb-3">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_notify_on_proposal_status]" value="1"
                 <?= !empty($existing_data['crm_notify_on_proposal_status']) ? 'checked' : '' ?>>
          <label class="form-check-label">Notify on Proposal Status Change</label>
          <small class="text-muted d-block">Triggered when <code>crm_proposals.status</code> changes (sent, approved, declined).</small>
        </div>

        <div class="form-check form-switch mb-3">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_notify_on_new_note]" value="1"
                 <?= !empty($existing_data['crm_notify_on_new_note']) ? 'checked' : '' ?>>
          <label class="form-check-label">Notify on New Note</label>
          <small class="text-muted d-block">Triggered when a row is inserted into <code>crm_notes</code>.</small>
        </div>

        <div class="form-check form-switch mb-0">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_notify_overdue_followups]" value="1"
                 <?= !empty($existing_data['crm_notify_overdue_followups']) ? 'checked' : '' ?>>
          <label class="form-check-label">Notify on Overdue Follow-ups</label>
          <small class="text-muted d-block">Alerts when <code>crm_leads.next_followup_date</code> is past due.</small>
        </div>

      </div>

      <!-- ── Data Quality ───────────────────────────────── -->
      <div class="card card-body border-bottom pb-3 mb-4">
        <div class="card-header bg-light-primary py-2 mb-3">
          <h6 class="mb-0 text-muted"><i class="ti ti-shield-check me-2"></i>Data Quality</h6>
        </div>

        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Require Email on Lead</span>
            <?php $re = (string)($existing_data['crm_require_email'] ?? '1'); ?>
            <select class="form-select" name="settings[crm_require_email]">
              <option value="1" <?= $re === '1' ? 'selected' : '' ?>>Yes</option>
              <option value="0" <?= $re === '0' ? 'selected' : '' ?>>No</option>
            </select>
          </div>
        </div>

        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Require Phone on Lead</span>
            <?php $rp = (string)($existing_data['crm_require_phone'] ?? '0'); ?>
            <select class="form-select" name="settings[crm_require_phone]">
              <option value="1" <?= $rp === '1' ? 'selected' : '' ?>>Yes</option>
              <option value="0" <?= $rp === '0' ? 'selected' : '' ?>>No</option>
            </select>
          </div>
        </div>

        <div class="mb-2">
          <div class="input-group">
            <span class="input-group-text crm-group">Prevent Duplicate Leads</span>
            <?php $pd = (string)($existing_data['crm_prevent_duplicates'] ?? '1'); ?>
            <select class="form-select" name="settings[crm_prevent_duplicates]">
              <option value="1" <?= $pd === '1' ? 'selected' : '' ?>>Enabled</option>
              <option value="0" <?= $pd === '0' ? 'selected' : '' ?>>Disabled</option>
            </select>
          </div>
        </div>

        <div class="form-check form-switch mb-3">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_require_verification_for_won]" value="1"
                 <?= !empty($existing_data['crm_require_verification_for_won']) ? 'checked' : '' ?>>
          <label class="form-check-label">Require Verification Before Won</label>
          <small class="text-muted d-block">Checks <code>crm_leads.data_verified = 1</code> before allowing <code>contract_signed</code> status.</small>
        </div>

        <div class="form-check form-switch mb-0">
          <input class="form-check-input" type="checkbox" role="switch"
                 name="settings[crm_track_data_changes]" value="1"
                 <?= !empty($existing_data['crm_track_data_changes']) ? 'checked' : '' ?>>
          <label class="form-check-label">Track Data Changes (Activity Log)</label>
          <small class="text-muted d-block">Writes to <code>crm_activity</code> on every significant field change.</small>
        </div>

      </div>

    </div>
    <!-- /col-md-6 -->

  </div>
</form>  
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* Show/hide default assignee row based on auto-assign toggle */
    const autoAssignToggle = document.querySelector('[name="settings[crm_auto_assign_new_leads]"]');
    const assigneeWrap     = document.getElementById('wrap_default_assignee');

    function syncAssigneeWrap() {
        if (!autoAssignToggle || !assigneeWrap) return;
        assigneeWrap.style.display = autoAssignToggle.checked ? '' : 'none';
    }

    if (autoAssignToggle) {
        autoAssignToggle.addEventListener('change', syncAssigneeWrap);
        syncAssigneeWrap();
    }

});

$('.js-assign-select').select2({
    templateResult: formatUser,
    templateSelection: formatUser
});

function formatUser(user) {
    if (!user.id) return user.text;

    var avatar = $(user.element).data('avatar');

    if (!avatar) return user.text;

    return $(
        '<span><img src="' + avatar + '" class="rounded-circle me-2" style="width:20px;height:20px;" />' 
        + user.text + '</span>'
    );
}
</script>